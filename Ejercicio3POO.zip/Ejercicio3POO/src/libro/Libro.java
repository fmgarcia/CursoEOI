package libro;

public class Libro {
	
	private String titulo;
	private String autor;
	private int ejemplares;
	private int prestados;

	
	/**
	 * Constructor por defecto
	 */
	public Libro() {
		// TODO Ap�ndice de constructor generado autom�ticamente
	}

	/**
	 * 
	 * @param titulo
	 * @param autor
	 * @param ejemplares
	 * @param prestados
	 */
	public Libro(String titulo, String autor, int ejemplares, int prestados) {
		super();
		this.titulo = titulo;
		this.autor = autor;
		this.ejemplares = ejemplares;
		this.prestados = prestados;
	}
	
	/**
	 * Constructor de copia
	 * @param libro
	 */
	public Libro(Libro libro) {
		this.titulo = libro.titulo;
		this.autor = libro.autor;
		this.ejemplares = libro.ejemplares;
		this.prestados = libro.prestados;
	}

	/**
	 * @return el titulo
	 */
	public String getTitulo() {
		return titulo;
	}

	/**
	 * @param titulo el titulo a establecer
	 */
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	/**
	 * @return el autor
	 */
	public String getAutor() {
		return autor;
	}

	/**
	 * @param autor el autor a establecer
	 */
	public void setAutor(String autor) {
		this.autor = autor;
	}

	/**
	 * @return el ejemplares
	 */
	public int getEjemplares() {
		return ejemplares;
	}

	/**
	 * @param ejemplares el ejemplares a establecer
	 */
	public void setEjemplares(int ejemplares) {
		this.ejemplares = ejemplares;
	}

	/**
	 * @return el prestados
	 */
	public int getPrestados() {
		return prestados;
	}

	/**
	 * @param prestados el prestados a establecer
	 */
	public void setPrestados(int prestados) {
		this.prestados = prestados;
	}

	/* (sin Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Libro [titulo=" + titulo + ", autor=" + autor + ", ejemplares=" + ejemplares + ", prestados="
				+ prestados + "]";
	}

	/**
	 * Funci�n que presta ejemplares de un libro
	 * Fran v.1.0 02/03/2020
	 * Fran v 1.1 03/03/2020 a�ado esto...
	 * @return true en caso de que queden ejemplares, false si no quedan ejemplares
	 */
	public boolean prestamo() {
		// TODO Ap�ndice de m�todo generado autom�ticamente
		
		if(prestados<ejemplares) {	// Si quedan libros por prestar
			prestados++;
			return true;
		}
		else {	// Si no quedan libros por prestar
			return false;
		}
				
	}

	public boolean devolucion() {
		// TODO Ap�ndice de m�todo generado autom�ticamente
		
		if(prestados>0) {
			prestados--;
			return true;
		}
		else {
			return false;
		}
				
	}

}
