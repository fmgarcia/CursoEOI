package com.fran.eoi_leerXml;

import java.io.File;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class App {
	
	public static void leerTodasAsignaturas() {
		try {
			// Al principio es solo comprobar si el fichero
			// tiene la estructara correcta
			File inputFile = new File("asignaturas.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			
			// Saca el nodo principal
			System.out.println("Elemento base : " + doc.getDocumentElement().getNodeName());
			// Coge todas las asignaturas y las guarda en una lista de nodos
			NodeList nList = doc.getElementsByTagName("asignatura");
			System.out.println();
			System.out.println("Recorriendo asignaturas...");
			// Recorro las asignaturas
			for (int temp = 0; temp < nList.getLength(); temp++) {
				// Coge asigantura a asignatura y la asigna temporalmente
				Node nNode = nList.item(temp);
				// Indica que es un nodo final
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					System.out.println("Codigo: " + eElement.getAttribute("id"));
					System.out.println("Nombre: " + eElement.getElementsByTagName("nombre").item(0).getTextContent());
					System.out.println(
							"Ciclo: " + eElement.getElementsByTagName("cicloFormativo").item(0).getTextContent());
					System.out.println("Curso: " + eElement.getElementsByTagName("curso").item(0).getTextContent());
					System.out
							.println("Profesor: " + eElement.getElementsByTagName("profesor").item(0).getTextContent());
					System.out.println();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void dom1() {
		try {
			File inputFile = new File("asignaturas.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("asignatura");

			System.out.println("Buscando asignaturas de segundo...");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					if (eElement.getElementsByTagName("curso").item(0)
							.getTextContent().equals("Segundo")) {
						System.out
								.println("Nombre: " + eElement.getElementsByTagName("nombre")
								.item(0).getTextContent());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void dom2() {
		Scanner sc = new Scanner(System.in);

		try {
			File inputFile = new File("coches.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("coche");

			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					if (eElement.getElementsByTagName("marca").item(0).getTextContent().equalsIgnoreCase("seat")) {
						System.out
								.println("Modelo: " + eElement.getElementsByTagName("modelo").item(0).getTextContent());
						System.out.println();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	
	public static void main(String[] args) {

		//leerTodasAsignaturas();
		//dom1();
		dom2();
	}
}
