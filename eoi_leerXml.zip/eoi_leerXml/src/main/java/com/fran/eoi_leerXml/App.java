package com.fran.eoi_leerXml;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.fran.eoi_leerXml.News;

import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class App {

	static List<News> news = new ArrayList<>(); // Lista de noticias

	public static void leerTodasAsignaturas() {
		try {
			// Al principio es solo comprobar si el fichero
			// tiene la estructara correcta
			File inputFile = new File("asignaturas.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();

			// Saca el nodo principal
			System.out.println("Elemento base : " + doc.getDocumentElement().getNodeName());
			// Coge todas las asignaturas y las guarda en una lista de nodos
			NodeList nList = doc.getElementsByTagName("asignatura");
			System.out.println();
			System.out.println("Recorriendo asignaturas...");
			// Recorro las asignaturas
			for (int temp = 0; temp < nList.getLength(); temp++) {
				// Coge asigantura a asignatura y la asigna temporalmente
				Node nNode = nList.item(temp);
				// Indica que es un nodo final
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					System.out.println("Codigo: " + eElement.getAttribute("id"));
					System.out.println("Nombre: " + eElement.getElementsByTagName("nombre").item(0).getTextContent());
					System.out.println(
							"Ciclo: " + eElement.getElementsByTagName("cicloFormativo").item(0).getTextContent());
					System.out.println("Curso: " + eElement.getElementsByTagName("curso").item(0).getTextContent());
					System.out
							.println("Profesor: " + eElement.getElementsByTagName("profesor").item(0).getTextContent());
					System.out.println();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void dom1() {
		try {
			File inputFile = new File("asignaturas.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("asignatura");

			System.out.println("Buscando asignaturas de segundo...");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					if (eElement.getElementsByTagName("curso").item(0).getTextContent().equals("Segundo")) {
						System.out
								.println("Nombre: " + eElement.getElementsByTagName("nombre").item(0).getTextContent());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void dom2() {
		Scanner sc = new Scanner(System.in);

		try {
			File inputFile = new File("coches.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("coche");

			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					if (eElement.getElementsByTagName("marca").item(0).getTextContent().equalsIgnoreCase("seat")) {
						System.out
								.println("Modelo: " + eElement.getElementsByTagName("modelo").item(0).getTextContent());
						System.out.println();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void dom3() {
		String fileName = "coches.xml";
		String buscarMarca;
		Scanner scn = new Scanner(System.in);
		ArrayList<Coche> list = new ArrayList<>();

		System.out.print("Introduce la marca a buscar: ");
		buscarMarca = scn.nextLine();

		try {

			File inputFile = new File(fileName);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();

			NodeList nList = doc.getElementsByTagName("coche");
			System.out.println();

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;

					if (eElement.getElementsByTagName("marca").item(0).getTextContent().equalsIgnoreCase(buscarMarca)) {

						list.add(new Coche(eElement.getElementsByTagName("marca").item(0).getTextContent(),
								eElement.getElementsByTagName("modelo").item(0).getTextContent(), Integer.parseInt(
										eElement.getElementsByTagName("cilindrada").item(0).getTextContent())));
					}

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		// Usando comparator por separado
		Comparator<Coche> comp = (Coche c1, Coche c2) -> {
			if (c2.getCilindrada() == c1.getCilindrada())
				return c2.getModelo().compareTo(c1.getModelo());

			return c2.getCilindrada() - c1.getCilindrada();
		};

		/*
		 * list.stream().sorted(comp).forEach(System.out::println);
		 */

		// Mi preferida
		list.stream().sorted((c1, c2) -> {
			if (c2.getCilindrada() == c1.getCilindrada())
				return c2.getModelo().compareTo(c1.getModelo());

			return c2.getCilindrada() - c1.getCilindrada();
		}).forEach(System.out::println);

		// Más fácil, pero solo ordena por un campo
		list.stream().sorted(Comparator.comparing(Coche::getCilindrada).reversed()).forEach(e -> System.out.println(e));

	}

	public static List<String> obtenerXmls() {

		try {
			URL url = new URL("https://www.marca.com/rss.html");
			URLConnection uc = url.openConnection();
			uc.connect();
			List<String> lines = new BufferedReader(new InputStreamReader(uc.getInputStream(), StandardCharsets.UTF_8))
					.lines() // Lo divide en lineas
					.filter(line -> line.contains(".xml") && !line.contains("link")).map(t -> {
						int inicio = t.indexOf("href");
						int fin = t.indexOf("xml");
						String urldepurada = t.substring(inicio + 6, fin + 3);
						return urldepurada;
					}).collect(Collectors.toList());
			/*
			 * for (String line : lines) { System.out.println(line); }
			 */
			return lines;
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static List<String> obtenerXmlsMundo() {

		try {
			URL url = new URL("http://rss.elmundo.es/rss/");
			URLConnection uc = url.openConnection();
			uc.connect();
			List<String> lines = new BufferedReader(new InputStreamReader(uc.getInputStream(), StandardCharsets.UTF_8))
					.lines() // Lo divide en lineas
					.filter(line -> line.contains("application/rss+xml") && !line.contains("data2")
							&& !line.contains("blogs"))
					.map(t -> {
						int inicio = t.indexOf("href");
						int fin = t.indexOf("xml");
						String urldepurada = t.substring(inicio + 6, fin + 3);
						urldepurada = urldepurada.replace("estaticos.elmundo", "e00-elmundo.uecdn");
						urldepurada = urldepurada.replace("http", "https");
						return urldepurada;
					}).collect(Collectors.toList());

			for (String line : lines) {
				System.out.println(line);
			}

			return lines;
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void leerPagina(String categorie) {
		URL url;
		Document doc;
		
		System.out.println("Tratando: " + categorie);
		
		try {
			url = new URL(categorie);
			URLConnection uc = url.openConnection();
			uc.connect();
			List<String> lines = new BufferedReader(new InputStreamReader(uc.getInputStream(), StandardCharsets.UTF_8)).lines().collect(Collectors.toList());
			//System.out.println(lines);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(url.openStream()); // Así se abre un xml de Internet
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("item");

			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					ArrayList<String> categoriesList = new ArrayList<>();
					for (int j = 0; j < eElement.getElementsByTagName("category").getLength(); j++) {
						categoriesList.add(eElement.getElementsByTagName("category").item(0).getTextContent());
					}

					if(eElement.getElementsByTagName("dc:creator").getLength()>0) {
						
					
						boolean isInTheList = news.stream()
								.anyMatch(
								a -> a.getGuid().equals(eElement.getElementsByTagName("guid").item(0).getTextContent()));
	
						if (!isInTheList)
							news.add(new News(eElement.getElementsByTagName("title").item(0).getTextContent(),
								eElement.getElementsByTagName("description").item(0).getTextContent(),
								eElement.getElementsByTagName("dc:creator").item(0).getTextContent(),
								eElement.getElementsByTagName("link").item(0).getTextContent(), categoriesList,
								eElement.getElementsByTagName("guid").item(0).getTextContent(),
								eElement.getElementsByTagName("pubDate").item(0).getTextContent()));
					}
				}			
			
			}
			
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	public static void imprimirNoticias() {

		int count = 1;
		for (News noticia : news) {
			System.out.println(count++ + " " + noticia);
		}
	}

	public static void leerMarca() {
		// Guardo todas las rutas de los ficheros xml
		// donde hay noticias en el marca
		List<String> xmlLeidos = obtenerXmls();
		for (String pagina : xmlLeidos) {
			leerPagina(pagina);
		}
		imprimirNoticias();
	}

	public static void leerMundo() {
		// Guardo todas las rutas de los ficheros xml
		// donde hay noticias en el marca
		List<String> xmlLeidos = obtenerXmlsMundo();
		for (String pagina : xmlLeidos) {
			leerPagina(pagina);
		}
		imprimirNoticias();
	}

	public static void main(String[] args) {

		// leerTodasAsignaturas();
		// dom1();
		// dom2();
		// dom3();
		// obtenerXmls();
		 leerMarca();
		// leerMundo();
	}
}
