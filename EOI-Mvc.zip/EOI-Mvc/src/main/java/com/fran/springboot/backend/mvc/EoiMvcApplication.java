package com.fran.springboot.backend.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EoiMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(EoiMvcApplication.class, args);
	}

}
