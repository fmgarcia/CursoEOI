package com.fran.jdbc1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App {

	static final String port = "3306";
	static final String database = "product-manager";
	static final String db = "jdbc:mysql://localhost:" + port + "/" + database + "?serverTimezone=UTC";
	static final String user = "root";
	static final String pass = "";

	public static void probarConexion() {
		try (Connection conn = DriverManager.getConnection(db, user, pass)) {
			System.out.println("Conexión establecida");
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public static void tearUp() {
		// Conexión
		// Borrar tablas
		// Crear tablas
		// Insertar Datos
	}

	public static void tearDown() {
		// Desconexión
	}

	public static void ejemplo1() {
		double acumulador = 0;
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery("select * from product")) {
			// Procesamiento del resultado
			while (rs.next()) {
				System.out.println("Fila " + rs.getRow() + ": con ID: " + rs.getInt("id") + " " + rs.getString("name"));
				acumulador += rs.getDouble("price");
			}
			System.out.println("El precio de todos los artículos es: " + acumulador);
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public static void ejemplo2() {
		String format = "%4d - %4.4s %-25.25s: %5.2f€\n";
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery("select * from product")) {

			while (rs.next()) {
				System.out.printf(format, rs.getInt("id"), rs.getString("reference"), rs.getString("name"),
						rs.getDouble("price"));
			}
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}

	}

	public static void ejemplo3() {
		String format = "%4d - %4.4s %-25.25s: %5.2f€\n";
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				// TYPE_SCROLL_INSENSITIVE nos permite navegar hacia atrás
				Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				ResultSet rs = st.executeQuery("select * from product")) {
			rs.afterLast(); // Nos situamos al final
			while (rs.previous()) { // Vamos hacia atrás
				System.out.printf(format, rs.getInt("id"), rs.getString("reference"), rs.getString("name"),
						rs.getDouble("price"));
			}
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public static void ejemplo4() {
		// Como actualizar una fila de un resultado de una consulta
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet rs = st.executeQuery("select * from product")) {
			rs.absolute(4); // Nos movemos a la cuarta fila del resultado
			rs.updateString("reference", "9010");
			rs.updateString("name", "Montaje de ordenador Fran");
			rs.updateRow(); // Los cambios se hacen efectivos en este momento
			System.out.println("Fila 4 actualizada correctamente");
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public static void ejemplo5() {
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet rs = st.executeQuery("select * from product")) {
			rs.moveToInsertRow(); // Nos movemos a la fila de inserción (obligado)
			rs.updateString("reference", "1968");
			rs.updateString("name", "Ratón gaming");
			rs.updateDouble("price", 16.50);
			rs.updateInt("category", 1); // Clave ajena a la tabla category
			rs.insertRow();// Los cambios se hacen efectivos en este momento
			rs.last(); // Nos movemos a la fila insertada (la última)
			System.out.println("Fila insertada. Id generada: " + rs.getInt("id"));
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public static void ejemplo6() {
		// Ejemplo Statement con introducción de datos por parte del usuario
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduzca el id del producto: ");
		String identificador = sc.nextLine();
		String sql = "select * from product where id=" + identificador;

		String format = "%4d - %4.4s %-25.25s: %5.2f€\n";
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(sql)) {

			while (rs.next()) {
				System.out.printf(format, rs.getInt("id"), rs.getString("reference"), rs.getString("name"),
						rs.getDouble("price"));
			}
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}

	}

	public static void ejemploPreparedStatement() {
		String format = "%4d - %4.4s %-25.25s: %5.2f€\n";
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				PreparedStatement st = conn.prepareStatement("select * from product where category = ?")) {

			st.setInt(1, 1); // category = 1
			try (ResultSet rs = st.executeQuery()) { // Dentro del try para que cierre el ResultSet
				while (rs.next()) {
					System.out.printf(format, rs.getInt("id"), rs.getString("reference"), rs.getString("name"),
							rs.getDouble("price"));
				}
			}
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}

	private static int insertProducto(String referencia, String nombre, double precio, int categoria) {
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				PreparedStatement st = conn.prepareStatement("insert into product values(NULL, ?, ?, ?, ?)",
						Statement.RETURN_GENERATED_KEYS);) {
			st.setString(1, referencia);
			st.setString(2, nombre);
			st.setDouble(3, precio);
			st.setInt(4, categoria);

			int filas = st.executeUpdate();
			if (filas > 0) {
				ResultSet keys = st.getGeneratedKeys();
				keys.first();
				return keys.getInt(1);
			} else {
				return -1;
			}
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
			return -1;
		}
	}

	private static boolean updateProducto(int id, String referencia, String nombre, double precio, int categoria) {
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				PreparedStatement st = conn.prepareStatement(
						"update product set reference = ?, name = ?, price = ?, category = ? where id = ?");) {
			st.setString(1, referencia);
			st.setString(2, nombre);
			st.setDouble(3, precio);
			st.setInt(4, categoria);
			st.setInt(5, id);

			int filas = st.executeUpdate();
			return filas > 0;
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
			return false;
		}
	}

	private static boolean deleteProducto(int id) {
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				PreparedStatement st = conn.prepareStatement("delete from product where id = ?");) {
			st.setInt(1, id);

			int filas = st.executeUpdate();
			return filas > 0;
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
			return false;
		}
	}

	private static boolean insertCategoriaProducto(String categoria, String referencia, String nombre, double precio)
 {
		boolean ok = true;
		try (Connection conn = DriverManager.getConnection(db, user, pass)) {
			try {
				conn.setAutoCommit(false);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ok = false;
			} // Permitimos transacciones
			try {
				PreparedStatement st = conn.prepareStatement("insert into category values(NULL, ?)",
						Statement.RETURN_GENERATED_KEYS);
				st.setString(1, categoria);
				st.executeUpdate();

				ResultSet keys = st.getGeneratedKeys();
				keys.first();
				int idCategoria = keys.getInt(1);
				System.out.println("Genero categoria: " + idCategoria);
				// Aquí insertaríamos el producto
				PreparedStatement st2 = conn.prepareStatement("insert into product values(NULL, ?, ?, ?, ?)",
						Statement.RETURN_GENERATED_KEYS);
				st2.setString(1, referencia);
				st2.setString(2, nombre);
				st2.setDouble(3, precio);
				st2.setInt(4, idCategoria);
				st2.executeUpdate();
				System.out.println("Todo OK! Ejecuto Commit");
				conn.commit(); // Todo ok!
			} catch (SQLException ex) {
				System.err.println(ex.getMessage());
				System.out.println("Algo salió mal! Ejecuto Rollback");
				conn.rollback(); // Error!
				ok = false;
			}
		}catch (SQLException ex) {
		System.err.println(ex.getMessage());
		return false;
		}
		return ok;
	}

	public static void main(String[] args) {
		// tearUp();
		// probarConexion();
		// tearDown();
		// ejemplo1();
		// ejemplo2();
		// ejemplo3();
		// ejemplo4();
		// ejemplo5();
		// ejemplo6();
		// ejemploPreparedStatement();
		/*
		 * int clavenueva = insertProducto("10099", "Ejemplo Insert", 10.50, 2);
		 * System.out.println("La clave del nuevo producto es: " + clavenueva);
		 */
		/*
		 * if(updateProducto(16, "10100", "Ejemplo Insert", 10.50, 2)) {
		 * System.out.println("Registro actualizado correctamente"); } else {
		 * System.out.println("No he encontrado ese identificador"); }
		 */
		/*
		 * if (deleteProducto(16)) {
		 * System.out.println("Registro borrado correctamente"); } else {
		 * System.out.println("No he encontrado ese identificador"); }
		 */

		insertCategoriaProducto("Nueva Categoria", "10553", "Ejemplo Transacción", 100.10);

	}
}
