package com.fran.eoiLambda;

public class User {

	private int id;
	private String nombre;
	
	/**
	 * Constructor vacio
	 */
	public User() {
		
	}
	/**
	 * Constructor con datos
	 * @param id
	 * @param nombre
	 */
	public User(int id, String nombre) {
		super();
		this.id = id;
		this.nombre = nombre;
	}
	
	/**
	 * Constructor de copia
	 * @param u
	 */
	public User(User u) {
		super();
		this.id = u.id;
		this.nombre = u.nombre;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", nombre=" + nombre + "]";
	}
	
}
