package com.fran.eoiLambda;

// Identifa que es una interfaz funcional
@FunctionalInterface
public interface MiNombre {
	String miNombre();
}
