package com.fran.eoiLambda;

import java.util.*;
import java.util.stream.*;

import com.fran.eoiLambda.User;

public class StreamPrueba {
	
	private static List<User> users;
	
	public static void setUp() {
		users = new ArrayList<>();
		users.add(new User(1,"Fernando"));
		users.add(new User(2,"Fran"));
		users.add(new User(3,"Arturo"));
		users.add(new User(4,"Masi"));
		users.add(new User(5,"Adrián"));
		users.add(new User(6,"Antonio"));
		users.add(new User(7,"Masi"));
		users.add(new User(7,"Masi"));
    }
	
	public static void main(String[] args) {
		
		setUp();
		// Las siguientes dos líneas son equivalentes
		Stream stream = Stream.of(users);
		users.stream();
		
		// forEach, que es siempre final
		users.stream()
		.forEach(e->System.out.println(e.getNombre() + " García")); // Impresión
		users.stream()
		.forEach(e->System.out.println(e.getId()*2));
		
		// Map y Collectors.toList
		// Map-> Permite realizar una transformación rápida de la lista original
		// Collectors.toList -> Nos permite sacar cosas del stream una vez finalizado el proceso
		
		List<String> nombres = users.stream().map(e->e.getNombre()).collect(Collectors.toList());
		System.out.println("La cantidad de nombres son: " + nombres.size());
		
		// filter
		List<User> usuariosfiltrados = users.stream()
				.filter(e->e.getNombre().length()>=3)	// Más de 2 letras	
				.filter(e->e.getId()%2==0)				// Los id pares
				.collect(Collectors.toList());
		imprimirLista(usuariosfiltrados);
		
		// Crear lista de aquellos nombres que empiezan por F e imprimirlos
		List<String> nombresEmpiezanF = users.stream()
				.map(e->e.getNombre())
				.filter(e->e.charAt(0)=='F')
				.collect(Collectors.toList());
		imprimirCadenas(nombresEmpiezanF);
		
		long nombresconF = users.stream()
		.map(e->e.getNombre())
		.filter(e->e.charAt(0)=='F')
		.count();  // devuelve 2
		
		// findFirst, devuelve un objeto del conjunto de objetos que le pasamos
		
		Optional<User> primero = users.stream()
				.filter(e->e.getNombre().equals("Masi"))
				.findFirst();
		User primero2 = users.stream()
				.filter(e->e.getNombre().equals("Masi"))
				.findFirst()
				.orElse(new User(1,"Masi"));	// Asigna valor x defecto si no encuentra
		System.out.println(primero2);
		
		// flatMap
		// coge datos de diferentes arrays y los concatena en uno solo
		
		List<String> cadenas = new ArrayList<String>();
		List<List<String>> listaDeListas = 
				new ArrayList<List<String>>(Arrays.asList(
						new ArrayList<String>(Arrays.asList("Fran","Fernando")),
						new ArrayList<String>(Arrays.asList("Arturo","Masi"))
						));
		List<String> lista1 = new ArrayList<String>();
		lista1.add("Fran");
		lista1.add("Fernando");
		List<String> lista2 = new ArrayList<String>();
		lista1.add("Arturo");
		lista1.add("Masi");
		List<List<String>> listaDeListas2 = 
				new ArrayList<List<String>>();
		listaDeListas2.add(lista1);
		listaDeListas2.add(lista2);
		
		List<String> nombres3 = listaDeListas2.stream()
				.flatMap(e->e.stream())
				.filter(e->e.charAt(0)=='M')
				.collect(Collectors.toList());
		System.out.println("Imprimiendo Nombres3:");
		imprimirCadenas(nombres3);
		
		// Peek
		// Actua como el forEach pero no es final
		
		List<User> users2 = users.stream()
				.peek(e->e.setNombre(e.getNombre() + " Apellido"))
				.collect(Collectors.toList());
		System.out.println("Imprimiendo users2:");
		imprimirLista(users2);
		
		// Skip y Limit
		// Skip salta un número de elementos
		// Limit limita el número de resultados
		String[] abc = {"a", "b", "c", "d", "e", "f", "g", "h"};
		List<String> abcfiltrado = Arrays.stream(abc)
				.skip(2)
				.limit(4)
				.collect(Collectors.toList());
		System.out.println("Imprimir abcfiltrado:");
		imprimirCadenas(abcfiltrado);
		
		// sorted
		List<User> ordenada1 = users.stream()
				.sorted(Comparator.comparing(User::getId))
				.limit(20)
				.collect(Collectors.toList());
		System.out.println("Imprimir ordenada1:");
		imprimirLista(ordenada1);
		
		List<User> ordenada2 = users.stream()
				.sorted(Comparator.comparing(User::getId).reversed())
				.skip(20)
				.limit(20)
				.collect(Collectors.toList());
		System.out.println("Imprimir ordenada2:");
		imprimirLista(ordenada2);
		
		users.stream()
		.sorted(Comparator.comparing(User::getId))
		.forEach(e->System.out.println(e));
		
		// Min y Max
		User min = users.stream()
				.min(Comparator.comparing(User::getId))
				.orElse(new User(1,"Fran"));
		User max = users.stream()
				.max(Comparator.comparing(User::getId))
				.orElse(new User(1,"Fran"));
		System.out.println("Imprimir min y max:");
		System.out.println("El id mínimo es: " + min.getId());
		System.out.println("El id máximo es: " + max.getId());
		
		// distinct
		String[] abcduplicados = {"a", "b", "c", "a", "b", "f", "c", "h"};
		List<String> abcfiltrado2 = Arrays.stream(abcduplicados)
				.distinct()
				.collect(Collectors.toList());
		System.out.println("Imprimir abcfiltrado2:");
		imprimirCadenas(abcfiltrado2);
		
		long nombresdistintos = users.stream().map(e->e.getNombre()).distinct().count();
		
		// allMath, anyMatch, noneMatch
		// devuelve valores booleanos, true o false
		
		boolean allMatch = users.stream()
				.map(e->e.getNombre())
				.allMatch(e->e.length()>=3);
		if(allMatch)
			System.out.println("Todos tienen más de 3 letras");
		else
			System.out.println("NO todos tienen más de 3 letras");
		
		boolean anyMatch = users.stream()
				.map(e->e.getNombre())
				.anyMatch(e->e.length()>=7);
		if(anyMatch)
			System.out.println("Alguno tiene más de 7 letras");
		else
			System.out.println("Ninguno tiene más de 7 letras");
		
		// ninguno es mayor o igual a 7 letras
		boolean noneMatch = users.stream()
				.map(e->e.getNombre())
				.noneMatch(e->e.length()>=7);
		
		// Sum, average, range
		
		long totalIds = users.stream()
				.mapToLong(e->e.getId())
				.sum();
		double mediaIds = users.stream()
				.mapToDouble(e->e.getId())
				.average()
				.orElse(0);
		System.out.println(IntStream.range(1, 100).sum());
		
		// reduce
		
		long resultado = users.stream()
				.mapToLong(e->e.getId())
				.reduce(100, Long::sum);
		System.out.println(resultado);
		
		// joining
		String nombresunidos = users.stream()
				.map(e->e.getNombre())
				.collect(Collectors.joining(" - "));
		System.out.println(nombresunidos);
		
		// toSet
		// Para cuando quieres garantizar que no hay elementos repetidos
		Set<Integer> idsNoDuplicados = users.stream()
				.map(e->e.getId())
				.collect(Collectors.toSet());
		
		// DoubleSummaryStatistics
		DoubleSummaryStatistics estadisticas = users.stream()
				.collect(Collectors.summarizingDouble(User::getId));
		
		System.out.println("La media es: " + estadisticas.getAverage());
		System.out.println("Los ids son: " + estadisticas.getCount());
		
		// partitionBy
		// Partir la lista original en 2 listas
		// una que cumple la condicion
		// y otra que no
		
		Map<Boolean,List<User>> esMayor = users.stream()
				.collect(Collectors.partitioningBy(e->e.getId()>4));
		
		System.out.println("Cumplen la condicion:");
		esMayor.get(true).stream().forEach(e->System.out.println(e.getId()));
		System.out.println("NO Cumplen la condicion:");
		esMayor.get(false).stream().forEach(e->System.out.println(e.getId()));
		
		// groupingBy
		Map<Character,List<User>> grupoAlfabetico = users.stream()
				.collect(Collectors.groupingBy(e->new Character(e.getNombre().charAt(0))));
		System.out.println("los que empiezan por F son:");
		grupoAlfabetico.get('F').stream().forEach(e->System.out.println(e.getNombre()));
		System.out.println("los que empiezan por M son:");
		grupoAlfabetico.get('M').stream().forEach(e->System.out.println(e.getNombre()));
		
		// mapping
		// Convierte una lista de objetos en otra lista de objetos que queramos
		System.out.println("-----------------------mapping-------------------------");
		List<String> personas = users.stream()
				.collect(Collectors.mapping(User::getNombre, Collectors.toList()));
		personas.stream().forEach(e -> System.out.println(e));
		
		// Stream Paralelo
		long tiempoinicial = System.currentTimeMillis();
		users.stream().forEach(e->UnSegundo(e.getId()));
		long tiempofinal = System.currentTimeMillis();
		System.out.println("El proceso dura : " + (tiempofinal-tiempoinicial));
		
		long tiempoinicialparalelo = System.currentTimeMillis();
		users.parallelStream().forEach(e->UnSegundo(e.getId()));
		long tiempofinalparalelo = System.currentTimeMillis();
		System.out.println("El proceso dura : " + (tiempofinalparalelo-tiempoinicialparalelo));
		
		
	}
	
	public static void UnSegundo(int usuario) {
		try {
			Thread.sleep(1000);
			System.out.println("acabado " + usuario);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void imprimirLista(List<User> lista) {
		lista.stream().forEach(e->System.out.println(e));
	}
	
	public static void imprimirCadenas(List<String> lista) {
		lista.stream().forEach(e->System.out.println(e));
	}
	
	
	
}
