package com.fran.eoiLambda;

import java.util.ArrayList;

/**
 * Hello world!
 *
 */
public class App 
{
	static ArrayList<User> usuarios;
	
    public static void main( String[] args )
    {
        /*() -> "Mi nombre es";
        (n)-> n*n;*/
    	
    	// Antes de existir las lambdas
    	MiNombre miNombreAnonima = new MiNombre() {
			@Override
			public String miNombre() {
				// TODO Auto-generated method stub
				return "Fran anónimo";
			}
    		
    	};
    	System.out.println(miNombreAnonima.miNombre());
    	
    	// Lo de antes con Lambdas
    	MiNombre miNombreLambda = () -> "Fran Lambda";
    	System.out.println(miNombreLambda.miNombre());
    	
    	// Otro ejemplo clásico de Lambdas
    	setUp();
    	for(User u: usuarios) {
    		if(u.getNombre().length()>=3 && u.getNombre().charAt(0)=='F')
    			System.out.println(u.getNombre());
    	}
    	// hace lo mismo que el for de arriba
    	usuarios.stream()
    	.filter(e->e.getNombre().length()>=3)
    	.filter(e->e.getNombre().charAt(0)=='F')
    	.forEach(e->System.out.println(e.getNombre()));
    	
    	
    }
    
    public static void setUp() {
    	usuarios = new ArrayList<>();
    	usuarios.add(new User(1,"Fernando"));
    	usuarios.add(new User(2,"Fran"));
    	usuarios.add(new User(3,"Arturo"));
    	usuarios.add(new User(4,"Masi"));
    	usuarios.add(new User(5,"Adrián"));
    	usuarios.add(new User(6,"Antonio"));   	
    }
}
