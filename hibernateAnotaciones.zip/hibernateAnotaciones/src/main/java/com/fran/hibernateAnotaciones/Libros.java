// default package
// Generated 29-ene-2020 15:00:28 by Hibernate Tools 5.4.7.Final
package com.fran.hibernateAnotaciones;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Libros implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	@Column(name="id", unique=true, nullable=false)
	private int id;
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="codautor")
	private Autores autores;
	@Column(name="titulo", length=60)
	private String titulo;

	public Libros() {
	}

	public Libros(int id) {
		this.id = id;
	}

	public Libros(int id, Autores autores, String titulo) {
		this.id = id;
		this.autores = autores;
		this.titulo = titulo;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Autores getAutores() {
		return this.autores;
	}

	public void setAutores(Autores autores) {
		this.autores = autores;
	}

	public String getTitulo() {
		return this.titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

}
