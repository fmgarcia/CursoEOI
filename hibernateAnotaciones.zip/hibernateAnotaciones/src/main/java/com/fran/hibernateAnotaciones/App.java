package com.fran.hibernateAnotaciones;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		if (session != null) {
			System.out.println("Sesión abierta");
		} else {
			System.out.println("Fallo en la sesión");
		}
		Query<Libros> consulta = session.createQuery("from Libros");
		List<Libros> resultados = consulta.list();

		for (Object resultado : resultados) {
			Libros libro = (Libros) resultado;
			System.out.println(libro.getId() + ": " + libro.getTitulo() + ", de " 
			+ (libro.getAutores()!=null?libro.getAutores().getNombre():"Anónimo"));
		}
        
        session.close();
    }
}
