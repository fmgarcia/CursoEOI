package com.fran.hibernateeoi2;

import org.hibernate.query.Query;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
	static SessionFactory sessionFactory;
    static Session session;
    
    public static void tearUp() {
    	sessionFactory = new Configuration().configure().buildSessionFactory();
    	session = sessionFactory.openSession();
    }
    
    public static void tearDown() {
    	session.close();
    }
    
    public static void probarConexion() {
    	if(session != null) {
        	System.out.println("Conexión establecida");
        }
        else {
        	System.out.println("Fallo en la conexión");
        }
    }
	
	public static void desactivarLog() {
		@SuppressWarnings("unused")
		org.jboss.logging.Logger logger = org.jboss.logging.Logger.getLogger("org.hibernate");
		java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.SEVERE);
	}
	
	public static void ejemplosLeer() {
        // Obtención de todos los libros con sus datos
        Query<Libros> consulta = session.createQuery("from Libros"); // Crea la consulta sobre la clase Libros
        List<Libros> resultados = consulta.list();	// Ejecuta la consulta creando la lista
        
        for(Libros resultado: resultados) {
        	System.out.println(resultado.getId() + ": " + resultado.getTitulo() + " del autor: " 
        	+ (resultado.getAutores()!=null?resultado.getAutores().getNombre():"Anónimo"));
        			
        }
        
        Query<Autores> consulta2 = session.createQuery("from Autores");
        List<Autores> resultados2 = consulta2.list();
        
        for(Autores resultado: resultados2) {
        	System.out.println(resultado.getNombre() + " ha escrito: ");
        	for(Libros libro: resultado.getLibroses()) {
        		System.out.println(libro.getTitulo());
        	}        	
        }
	}
	
	public static void ejemploInsertar() {
		try {
			Transaction transaction = session.beginTransaction();
			Libros libronuevo = new Libros(11,new Autores("FROJA"),"Libro insertado");
			session.save(libronuevo);
			transaction.commit();
			System.out.println("El libro ha sido insertado correctamente");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("No se ha podido insertar el libro");
			//e.printStackTrace();
		}
	}
	
	public static void ejemploUpdate() {
		// En este ejemplo cambiaremos a un libro el nombre
		Query<Libros> consulta = session.createQuery("from Libros where id=1"); // Obtiene el dato
		List resultados = consulta.list();
		Transaction transaction = session.beginTransaction();
		Libros libronuevo = (Libros) resultados.get(0);	// Me enlazo con el objeto a cambiar
		libronuevo.setTitulo("Libro modificado");		// modifico el objeto
		session.update(libronuevo);						// Actualizo el objeto
		transaction.commit();							// Confirmo el cambio en la base de datos
		
	}
	
	public static void ejemploBorrar() {
		try {
			Query<Libros> consulta = session.createQuery("from Libros where id=10"); // Obtiene el dato
			List resultados = consulta.list();
			if(resultados.size()>0) {
				Transaction transaction = session.beginTransaction();
				session.delete(resultados.get(0));						// Actualizo el objeto
				transaction.commit();							// Confirmo el cambio en la base de datos
				System.out.println("Elemento borrado correctamente");
			}
			System.out.println("No existe elemento con esa ID");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("No se ha podido borrar el elemento");
			e.printStackTrace();
		}
	}
	
    public static void main( String[] args )
    {
    	desactivarLog();
    	tearUp();
    	//probarConexion();        
        //ejemplosLeer();
    	//ejemploInsertar();
    	//ejemploUpdate();
    	ejemploBorrar();
        
        tearDown();
        
        
    }
}
