package com.fran.hibernateeoi3;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

// https://docs.jboss.org/hibernate/orm/5.4/userguide/html_single/Hibernate_User_Guide.html
/**
 * Hello world!
 *
 */
public class App 
{
	static SessionFactory sessionFactory;
    static Session session;
    
    public static void tearUp() {
    	sessionFactory = new Configuration().configure().buildSessionFactory();
    	session = sessionFactory.openSession();
    }
    
    public static void tearDown() {
    	session.close();
    }
    
    public static void desactivarLog() {
		@SuppressWarnings("unused")
		org.jboss.logging.Logger logger = org.jboss.logging.Logger.getLogger("org.hibernate");
		java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.SEVERE);
	}
    
    public static void probarConexion() {
    	if(session != null) {
        	System.out.println("Conexión establecida");
        }
        else {
        	System.out.println("Fallo en la conexión");
        }
    }
    
    public static void obtenerInformacionLibros() {
    	// Obtención de todos los libros con sus datos con lenguaje HQL
        Query<Libros> consulta = session.createQuery("from Libros"); // Crea la consulta sobre la clase Libros
        List<Libros> resultados = consulta.list();	// Ejecuta la consulta creando la lista
        
        for(Libros resultado: resultados) {
        	System.out.println(resultado.getId() + ": " + resultado.getTitulo() + " de los autores: "); 
        	resultado.getAutoreses().forEach(e->System.out.println(e.getNombre()));        			
        }
    }
    
    public static void obtenerInformacionAutores() {
    	// Obtención de todos los autores con sus datos con lenguaje HQL
        Query<Autores> consulta = session.createQuery("from Autores"); // Crea la consulta sobre la clase Libros
        List<Autores> resultados = consulta.list();	// Ejecuta la consulta creando la lista
        
        for(Autores resultado: resultados) {
        	System.out.println(resultado.getCod() + ": " + resultado.getNombre() + " ha escrito: ");
        	if(resultado.getLibroses().size()>0)
        		resultado.getLibroses().forEach(e->System.out.println("El libro con código " + 
        			e.getId() + " de título " + e.getTitulo()));
        	else
        		System.out.println("Este autor no tiene todavía libros publicados");
        }
    }
    
    public static void ejemploNativeQuery(String cadenabusqueda) {
    	// Obtención de libros con SQL standSard
    	List<Libros> listalibros = session.createNativeQuery("Select * from libros where titulo like :cadena")
    			.addEntity(Libros.class)
    			.setParameter("cadena", cadenabusqueda)
    			.list();
    	for(Libros libro: listalibros) {
    		System.out.println(libro.getTitulo());
    	}
    }
	
    public static void main( String[] args )
    {
    	desactivarLog();
    	tearUp();
    	//probarConexion();
    	//obtenerInformacionLibros();
    	//obtenerInformacionAutores();
    	ejemploNativeQuery("%a%");
    	tearDown();
    	
    }
}
