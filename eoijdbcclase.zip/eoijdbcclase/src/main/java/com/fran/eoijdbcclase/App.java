package com.fran.eoijdbcclase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.sql.PooledConnection;

import com.mysql.cj.jdbc.MysqlConnectionPoolDataSource;

/**
 * Hello world!
 *
 */
public class App {
	static final String db = "jdbc:mysql://localhost:3306/product-manager?serverTimezone=UTC";
	static final String user = "root";
	static final String pass = "";
	static Scanner sc;

	public static void probarConexion() {
		try (Connection conn = DriverManager.getConnection(db, user, pass)) {
			System.out.println("Conexión establecida");
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public static void select() {

		String sql = "select * from product";

		try (Connection conn = DriverManager.getConnection(db, user, pass);
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(sql)) {

			double price = 0.0;
			// bucle que recorre los datos
			while (rs.next()) {
				System.out.println("Fila " + rs.getRow() + ": " + rs.getString("name") + " " + rs.getDouble("price"));
				// System.out.println("Fila " + rs.getRow() + ": " + rs.getString(3));
				price += rs.getDouble("price");
			}
			System.out.println("El precio de todos los productos es: " + price);

		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}

	}

	public static void selectFormateada() {
		String format = "%4d - %4.4s %-25.25s: %5.2f€\n";
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery("select * from product")) {

			while (rs.next()) {
				System.out.printf(format, rs.getInt("id"), rs.getString("reference"), rs.getString("name"),
						rs.getDouble("price"));
			}
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public static void selectAtras() {

		String format = "%4d - %4.4s %-25.25s: %5.2f€\n";
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				// TYPE_SCROLL_INSENSITIVE nos permite navegar hacia atrás
				Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				ResultSet rs = st.executeQuery("select * from product")) {
			rs.afterLast(); // Nos situamos al final
			while (rs.previous()) { // Vamos hacia atrás
				System.out.printf(format, rs.getInt("id"), rs.getString("reference"), rs.getString("name"),
						rs.getDouble("price"));
			}

		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}

	}

	public static void sumarImparesReferencias() {
		String format = "%4d - %4.4s %-25.25s: %5.2f€\n";
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery("select * from product")) {

			double price = 0.0;
			while (rs.next()) {
				if (Integer.parseInt(rs.getString("reference").charAt(0) + "") % 2 != 0) {
					System.out.printf(format, rs.getInt("id"), rs.getString("reference"), rs.getString("name"),
							rs.getDouble("price"));
					price += rs.getDouble("price");
				}
			}
			System.out.println("El precio de todos los productos impares es: " + price);

		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public static void actualizarResulset() {
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet rs = st.executeQuery("select * from product")) {
			rs.absolute(4); // Nos movemos a la cuarta fila del resultado
			rs.updateString("reference", "9005");
			rs.updateString("name", "Montaje de ordenador 2");
			rs.updateRow(); // Los cambios se hacen efectivos en este momento
			System.out.println("Fila 4 actualizada correctamente");
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public static void actualizarResulsetMasivo() {
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet rs = st.executeQuery("select * from product")) {
			while (rs.next()) {
				rs.updateString("name", rs.getString("name").toUpperCase() + " FRAN");
				rs.updateRow(); // Los cambios se hacen efectivos en este momento
			}
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public static void insertarFila(String reference) {
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet rs = st.executeQuery("select * from product")) {
			rs.moveToInsertRow(); // Nos movemos a la fila de inserción (obligado)
			rs.updateString("reference", reference);
			rs.updateString("name", "Ratón gaming");
			rs.updateDouble("price", 16.50);
			rs.updateInt("category", 1); // Clave ajena a la tabla category
			rs.insertRow();// Los cambios se hacen efectivos en este momento
			rs.last(); // Nos movemos a la fila insertada (la última)
			System.out.println("Fila insertada. Id generada: " + rs.getInt("id"));
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public static void ejemploPreparedStatement(String nombre) {
		String format = "%4d - %4.4s %-25.25s: %5.2f€\n";
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				PreparedStatement st = conn.prepareStatement("select * from product where category = ? and name = ?")) {

			st.setInt(1, 1); // category = 1
			st.setString(2, nombre);
			try (ResultSet rs = st.executeQuery()) { // Dentro del try para que cierre el ResultSet
				while (rs.next()) {
					System.out.printf(format, rs.getInt("id"), rs.getString("reference"), rs.getString("name"),
							rs.getDouble("price"));
				}
			}
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public static void ejemploInyeccion(String nombre) {

		String sql = "select * from product where name= '" + nombre + "'";

		try (Connection conn = DriverManager.getConnection(db, user, pass);
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(sql)) {

			double price = 0.0;
			// bucle que recorre los datos
			while (rs.next()) {
				System.out.println("Fila " + rs.getRow() + ": " + rs.getString("name") + " " + rs.getDouble("price"));
				// System.out.println("Fila " + rs.getRow() + ": " + rs.getString(3));
				price += rs.getDouble("price");
			}
			System.out.println("El precio de todos los productos es: " + price);

		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}

	}

	private static int insertProducto(String referencia, String nombre, double precio, int categoria) {
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				PreparedStatement st = conn.prepareStatement("insert into product values(NULL, ?, ?, ?, ?)",
						Statement.RETURN_GENERATED_KEYS);) {
			st.setString(1, referencia);
			st.setString(2, nombre);
			st.setDouble(3, precio);
			st.setInt(4, categoria);

			int filas = st.executeUpdate();
			if (filas > 0) {
				ResultSet keys = st.getGeneratedKeys();
				keys.first();
				return keys.getInt(1);
			} else {
				return -1;
			}
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
			return -1;
		}
	}

	private static boolean updateProducto(int id, String referencia, String nombre, double precio, int categoria) {
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				PreparedStatement st = conn.prepareStatement(
						"update product set reference = ?, name = ?, price = ?, category = ? where id = ?");) {
			st.setString(1, referencia);
			st.setString(2, nombre);
			st.setDouble(3, precio);
			st.setInt(4, categoria);
			st.setInt(5, id);

			int filas = st.executeUpdate();

			return filas > 0;
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
			return false;
		}
	}

	private static boolean deleteProducto(int id) {
		try (Connection conn = DriverManager.getConnection(db, user, pass);
				PreparedStatement st = conn.prepareStatement("delete from product where id = ?");) {
			st.setInt(1, id);

			int filas = st.executeUpdate();
			return filas > 0;
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
			return false;
		}
	}

	private static boolean insertCategoriaProducto(String categoria, String referencia, String nombre, double precio)
			throws SQLException {
		boolean ok = true;
		try (Connection conn = DriverManager.getConnection(db, user, pass)) {
			conn.setAutoCommit(false); // Desactivar el auto commit
			try {
				PreparedStatement st = conn.prepareStatement("insert into category values(NULL, ?)",
						Statement.RETURN_GENERATED_KEYS);
				st.setString(1, categoria);
				st.executeUpdate();

				ResultSet keys = st.getGeneratedKeys();
				keys.first();
				int idCategoria = keys.getInt(1);
				System.out.println("categoria insertada: " + idCategoria);
				// Aquí insertaríamos el producto
				PreparedStatement st2 = conn.prepareStatement(
						"insert into product(id,reference,name,price,category) values(NULL, ?, ?, ?, ?)",
						Statement.RETURN_GENERATED_KEYS);
				st2.setString(1, referencia);
				st2.setString(2, nombre);
				st2.setDouble(3, precio);
				// st2.setInt(4, idCategoria+1); // Esto lo hace fallar
				st2.setInt(4, idCategoria);

				int filas = st2.executeUpdate();

				conn.commit(); // Todo ok!
			} catch (SQLException ex) {
				System.err.println(ex.getMessage());
				conn.rollback(); // Error!
				ok = false;
			}
		}
		return ok;
	}

	public static void ejemploPool() {
		MysqlConnectionPoolDataSource ds = new MysqlConnectionPoolDataSource();
		ds.setDatabaseName("product-manager");
		ds.setServerName("localhost");
		ds.setPortNumber(3306);
		ds.setUser("root");
		ds.setPassword("");
		PooledConnection pcon = null;
		try {
			pcon = ds.getPooledConnection();	// hace 100 conexiones simultaneas
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String format = "%4d - %4.4s %-25.25s: %5.2f€\n";
		try (Connection conn = pcon.getConnection();
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery("select * from product")) {

			while (rs.next()) {
				System.out.printf(format, rs.getInt("id"), rs.getString("reference"), rs.getString("name"),
						rs.getDouble("price"));
			}
		} catch (SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public static void main(String[] args) {
		sc = new Scanner(System.in);
		// probarConexion();
		// select();
		// selectFormateada();
		// selectAtras();
		// sumarImparesReferencias();
		// actualizarResulset();
		// actualizarResulsetMasivo();
		// insertarFila("1234");
		// insertarFila("1235");
		// System.out.println("Introduzca nombre: ");
		// ejemploPreparedStatement(sc.nextLine());
		// System.out.println("Insertado el registro número " + insertProducto("1238",
		// "Fran", 100, 1));

		// Ejemplo Update
		/*
		 * if (updateProducto(1, "1234", "FRAN", 1000, 1)) {
		 * System.out.println("Actualizado correctamente"); } else {
		 * System.out.println("No se encontró el registro para actualizar"); }
		 */

		// Ejemplo Delete
		/*
		 * if (deleteProducto(1)) { System.out.println("Borrado correctamente"); } else
		 * { System.out.println("No se encontró el registro para borrar"); }
		 */

		// Ejemplo Transacción
		/*try {
			insertCategoriaProducto("Categoria Prueba", "2347", "Producto prueba", 1000);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		ejemploPool();

	}
}
