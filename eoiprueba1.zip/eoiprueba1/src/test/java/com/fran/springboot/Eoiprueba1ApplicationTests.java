package com.fran.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Eoiprueba1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
