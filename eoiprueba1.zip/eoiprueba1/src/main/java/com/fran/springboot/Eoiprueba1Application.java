package com.fran.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Eoiprueba1Application {

	public static void main(String[] args) {
		SpringApplication.run(Eoiprueba1Application.class, args);
	}

}
