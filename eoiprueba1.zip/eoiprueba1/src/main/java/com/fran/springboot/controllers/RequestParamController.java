package com.fran.springboot.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/params")
public class RequestParamController {
	
	@GetMapping({"/", ""})
	public String index() {
		return "params/index";	// Thymeleaf que carga
	}
	
	// Ejemplo de RequestParam
	// Esto sirve para coger la cadena pasada como parámetro
	@GetMapping({"/string"})
	public String param(@RequestParam(name="texto", required=false, 
					defaultValue="algún valor...") String texto, @RequestParam Integer numero,
			Model model) {
		model.addAttribute("resultado","El texto es " + texto + " y el número es " + numero);
		return "params/ver";	// Thymeleaf que carga
	}

}
