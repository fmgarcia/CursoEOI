package com.fran.springboot.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/variables")
public class PathVariableController {
	
	@GetMapping({"/", ""})
	public String index(Model model) {
		model.addAttribute("titulo","Enviar parámetros de la ruta {@PathVariable}");
		return "variables/index";	// Thymeleaf que carga
	}
	
	@GetMapping({"/string/{texto}"})
	public String param(@PathVariable String texto, Model model) {
		model.addAttribute("titulo","Enviar parámetros de la ruta {@PathVariable}");
		model.addAttribute("resultado","El texto es " + texto);
		return "variables/ver";	// Thymeleaf que carga
	}
	
	@GetMapping({"/string/{texto}/{numero}"})
	public String param(@PathVariable String texto,@PathVariable Integer numero, Model model) {
		model.addAttribute("titulo","Enviar parámetros de la ruta {@PathVariable}");
		model.addAttribute("resultado","El texto es " + texto + " y el numero es: " + numero);
		return "variables/ver";	// Thymeleaf que carga
	}

}
