package com.fran.springboot.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fran.springboot.models.Usuario;

@Controller
@RequestMapping("/app")
public class IndexController {

	@GetMapping({"/index", "/", "", "/home"})
	public String index() {
		return "index";
	}
	
	@GetMapping("/perfil")
	public String perfil(Model model) {
		/*Usuario usuario = new Usuario();
		usuario.setNombre("Fran");
		usuario.setApellido("García");
		usuario.setEmail("fran@iessanvicente.com");
		model.addAttribute("usuario", usuario);*/
		/*List<Usuario> usuarios = new ArrayList<Usuario>();
		usuarios.add(new Usuario("Fran", "García","fran@iessanvicente.com"));
		usuarios.add(new Usuario("Arturo", "Bernal","arturo@iessanvicente.com"));
		usuarios.add(new Usuario("Fernando", "Ruíz","fernando@iessanvicente.com"));
		model.addAttribute("usuarios", usuarios);*/
		model.addAttribute("titulo", "Lista de Usuarios");
		return "perfil";		
	}
	
	// Esto no es un endpoint. Equivale a crear una variable global
	// que puede ser usada en todas las vistas.
	@ModelAttribute("usuarios")
	public List<Usuario> poblarUsuarios(){
		List<Usuario> usuarios = new ArrayList<Usuario>();
		usuarios.add(new Usuario("Fran", "García","fran@iessanvicente.com"));
		usuarios.add(new Usuario("Arturo", "Bernal","arturo@iessanvicente.com"));
		usuarios.add(new Usuario("Fernando", "Ruíz","fernando@iessanvicente.com"));
		return usuarios;
	}
	
	
}
